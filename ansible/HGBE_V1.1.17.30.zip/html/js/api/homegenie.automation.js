//
// namespace : HG.Automation namespace
// info      : -
//
HG.Automation = HG.Automation || {};