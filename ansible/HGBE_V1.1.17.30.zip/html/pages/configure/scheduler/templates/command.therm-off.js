﻿// switch off all the selected thermostat modules
$$.boundModules.command('Thermostat.ModeSet')
  .set('Off');
