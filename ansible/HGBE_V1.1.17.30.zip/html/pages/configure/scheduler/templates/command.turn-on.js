﻿// turn on all selected modules
$$.boundModules.on();
