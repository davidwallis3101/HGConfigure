﻿// turn off all selected modules
$$.boundModules.off();
