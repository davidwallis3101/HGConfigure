﻿// level is a decimal value between 0 and 1 (eg. 0.5 = 50%)
level = 0.5;
// set the level
$$.boundModules.level = level;
